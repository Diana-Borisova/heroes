package com.softuni.heros.entity;

import lombok.Getter;

@Getter
public enum ClassEnum {

    warrior, archer, mage;

}
